struct node* ins_at_beg(struct node* head)
{
    struct node* change, *temp;
    temp=new_node();
    if(head==NULL)
    {
        head=temp;
    }
    else{
        temp->next=head;
        head=temp;
    }
    return head;
}

struct node* ins_end(struct node *head)
{
    struct node* change, *temp;
    if(head==NULL)
    {
        head=new_node();
        return head;
    }
    while(change->next!=NULL)
    {
        change=change->next;
    }
    temp=new_node();
    change->next=temp;

    return head;
}

struct node* ins_n_pos(struct node *head)
{
    struct node* change, *temp;
    int n,i;
    int count=0;
    change=head;
    while(change!= NULL)
    {
        change=change->next;
        count++;
    }
    printf("Enter position\n");
    scanf("%d",&n);
    while(n>=count && n<0)
    {
        printf("RE-ENTER n\n");
        scanf("%d",&n);
    }

    if (n==1)
        head= ins_at_beg(head);
    else{
        change=head;
        for(i=0; i<=n-2; i++)
        {
            change=change->next;
        }
        temp=new_node();
        temp->next=change->next;
        change->next=temp;
    }
    return head;
}

struct node* ins_after_val_n(struct node *head)
{
    struct node* change=head, *temp;
    int n;
    printf("Enter value\n");
    scanf("%d", &n);

    if(head==NULL)
    {
        printf("List doesn't exist\n");
    }
    else{
        while(change!=NULL && change->data!=n)
        {
            change=change->next;
        }

        if(change==NULL){
            printf("Value doesn't exist\n");
            return head;
        }

        printf("The value to be inserted.  ");
        temp= new_node();
        temp->next=change->next;
        change->next=temp;
    }
    return head;
}

struct node* ins_before_val_n(struct node *head)
{
    struct node* change=head, *temp;
    int n;
    printf("Enter value to be searched\n");
    scanf("%d", &n);

    if(head==NULL)
    {
        printf("List doesn't exist\n");
    }
    else if(head->data==n){
        printf("The value to be inserted. ");
        head=ins_at_beg(head);
    }
    else{
        while(change->next!=NULL && change->next->data!=n)
        {
            change=change->next;
        }

        if(change->next==NULL){
            printf("Value doesn't exist\n");
        }
        else{
             printf("The value to be inserted.  ");
             temp= new_node();
             temp->next=change->next;
             change->next=temp;
        }
    }
    return head;
}
