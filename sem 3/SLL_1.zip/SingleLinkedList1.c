#include <stdio.h>
#include <stdlib.h>
#include "create.h"
#include "insert.h"
#include "delete.h"
#include "print_count_search.h"

struct node* node_r()
{
    struct node* temp= (struct node*)malloc(sizeof(struct node));
    temp->next=NULL;
    return temp;
}

struct node* reverse(struct node *head)
{
    struct node* head1=NULL, *temp, *change=head;
    if(head==NULL)
    {
        printf("First create a list:\n");
    }
    else{
        if(head1==NULL)
        {
            temp=node_r();
            temp->data=change->data;
            head1=temp;
            change=change->next;
        }
        while(change!=NULL)
        {
            temp=node_r();
            temp->data=change->data;
            temp->next=head1;
            head1=temp;
            change=change->next;
        }
    }
    free(head);
    return head1;
}

int main()
{
    struct node* head= NULL;
    int option=0, count;
    char choice;
    do{
        printf("Enter option\n");
        scanf("%d", &option);
        switch(option)
        {
             case 1:  getchar();
                      printf("Enter choice:\n");
                      scanf("%c",&choice);
                      switch(choice)
                      {
                          case 'a':  head=n_node_list(head);
                                     break;
                          case 'b':  head=list(head);
                                     break;
                      }
                      break;
             case 2:  getchar();
                      scanf("%c", &choice);
                      switch(choice)
                      {
                          case 'a': head=ins_at_beg(head);
                                    break;
                          case 'b': head=ins_end(head);
                                    break;
                          case 'c': head= ins_n_pos(head);
                                    break;
                          case 'd': head= ins_after_val_n(head);
                                    break;
                          case 'e': head= ins_before_val_n(head);
                                    break;
                      }
                      break;
             case 3:  getchar();
                      scanf("%c",&choice);
                      switch(choice)
                      {
                          case 'a':head=del_1st_node(head);
                                   break;
                          case 'b':head=del_last_node(head);
                                   break;
                          case 'c':head=del_n_val_node(head);
                                   break;
                          case 'd':head=del_val_before_n_node(head);
                                   break;
                          case 'e':head=del_val_after_n_node(head);
                                   break;
                      }
                      break;
             case 4:  print_node(head);
                      break;
             case 5:  count= count_list(head);
                      break;
             case 6:  head=reverse(head);
                      break;
             case 7:  search(head);
                      break;

         }
         printf("To continue press 1 and 0 to exit\n");
         scanf("%d",&option);
    }while(option);
    free(head);
    return 0;
}
