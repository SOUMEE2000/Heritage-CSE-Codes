void print_node(struct node*head)
{
    struct node* change;
    change=head;
    while(change!= NULL)
    {
        printf("%d  ",change->data);
        change=change->next;
    }
    printf("\n");
}

int count_list(struct node *head)
{
    int count=0;
    struct node* change=head;
    while(change!= NULL)
    {
        change=change->next;
        count++;
    }

    printf("%d",count);
    return count;
}

void search(struct node*head)
{
    struct node* change=head;
    int data,count=0;
    printf("Enter data to be searched\n");
    scanf("%d",&data);
    while(change!=NULL)
    {
        count++;
        if(change->data==data)
            break;
        change=change->next;
    }

    if(change->data==data)
        printf("Element present at position %d\n",count);
    else
        printf("Not found\n");
    return;
}
