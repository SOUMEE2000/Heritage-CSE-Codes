struct node * del_1st_node(struct node * head)
{
    struct node* temp;
    if(head==NULL)
    {
        printf("Create a list to delete it.\n");
        return head;
    }
    temp= head;
    head= head->next;
    free(temp);
    printf("First node deleted\n");
    return head;
}

struct node* del_last_node(struct node *head)
{
    struct node *change=head, *temp;
    if(head==NULL)
    {
       printf("Create a list to delete it.\n");
       return head;
    }

    while(change->next->next!=NULL)
    {
        change=change->next;
    }
    temp=change->next;
    change->next=NULL;
    free(temp);
    printf("Last node deleted\n");
    return head;
}

struct node* del_n_val_node(struct node *head)
{
    struct node *change=head, *temp;
    if(head==NULL)
    {
       printf("Create a list to delete it.\n");
       return head;
    }

    int n;
    printf("Enter node to be deleted:\n");
    scanf("%d",&n);
    if(head->data==n)
        head=del_1st_node(head);
    else{
         while(change->next!=NULL && change->next->data!=n)
         {
             change=change->next;
         }
         if(change->next ==NULL)
         {
             printf("Value not found.\n");
         }
         else{
               temp=change->next;
               change->next=temp->next;
               free(temp);
            }
       }
    return head;
}

struct node* del_val_after_n_node(struct node *head)
{
    struct node *change=head, *temp;
    if(head==NULL)
    {
       printf("Create a list to delete it.\n");
       return head;
    }

    int n;
    printf("Enter requisite node:\n");
    scanf("%d",&n);

    while(change->next!=NULL && change->data!=n)
       {
           change=change->next;
       }
    if(change->next==NULL)
       {
           printf("No node after that.\n");
       }
    else{
            temp=change->next;
            change->next=temp->next;
            free(temp);
        }
    return head;
}

struct node* del_val_before_n_node(struct node *head)
{
    struct node *change=head, *temp;
    if(head==NULL)
    {
       printf("Create a list to delete it.\n");
       return head;
    }

    int n;
    printf("Enter node to be deleted:\n");
    scanf("%d",&n);
    if(head->data==n){
            printf("This only is the first node\n");
    }
    else if(head->next->data==n)
    {
        head= del_1st_node(head);
    }
    else{
         while(change->next->next!=NULL && change->next->next->data!=n)
         {
             change=change->next;
         }
         if(change->next->next==NULL)
         {
             printf("Value not found.\n");
         }
         else{
               temp=change->next;
               change->next=temp->next;
               free(temp);
            }
       }
    return head;
}
