struct node
{
    int data;
    struct node* next;
};

struct node* new_node()
{
    struct node *temp= (struct node*)malloc(sizeof(struct node));
    printf("Enter data\n");
    scanf("%d", &temp->data);
    temp->next=NULL;
    return temp;
}

struct node* list(struct node* head)
{
    int choice;
    struct node* change;

    do{

       struct node *temp= new_node();
       if(head==NULL)
       {
           head=temp;
           change=head;

       }
       else
       {
           change->next=temp;
           change=temp;
       }
       printf("Press 1 to continue 0 to finish\n");
       scanf("%d", &choice);

     }while(choice);
    return head;
}

struct node *n_node_list(struct node *head)
{
    int i, n;
    struct node *change;
    if(head!=NULL)
    {
        printf("List exists");
    }
    else
    {
        printf("No. of nodes:\n");
        scanf("%d",&n);
        for(i=1; i<n+1; i++)
        {
            struct node* temp= new_node();
            if(i==1)
            {
                head=temp;
                change=head;
            }
            else
            {
                change->next=temp;
                change= temp;
            }

        }
    }
    return head;
}
