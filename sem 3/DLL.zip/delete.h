struct node* delete_1st_node(struct node* head)
{
    head->next->prev=head;
    head=head->next;
    printf("1st node deleted.\n");
    return head;
}

struct node* delete_n_val(struct node* head)
{
    struct node *temp, *change=head;
    int n;
    printf("\nEnter n\n");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("List doesn't exist\n");
    }
    else if(head->data==n)
    {
        head=delete_1st_node(head);
    }
    else{

         while(change!=NULL && change->data!=n)
        {
            change=change->next;
        }
        if(change==NULL)
       {
            printf("Not found n\n");
       }
       else if(change->next==NULL)
       {
           change->prev->next=NULL;
           temp=change;
           free(temp);
       }
       else{
           change->prev->next=change->next;
           change->next->prev=change->prev;
           temp=change;
           free(temp);
       }
    }
    return head;

}

struct node* del_at_end(struct node* head)
{
    struct node* change=head, *temp;
    if(head==NULL)
    {
        printf("Create a list first.\n");
        return head;
    }

    if(head->next==NULL)
    {
        free(head);
        head=NULL;
        printf("Last node deleted.\n");
        return head;
    }

    while(change->next->next!=NULL)
    {
        change=change->next;
    }
    temp=change->next;
    change->next=NULL;
    free(temp);
    return head;
}

struct node* delete_after_n_val(struct node* head)
{
    struct node *temp, *change=head;
    int n;
    printf("Enter n: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("List doesn't exist\n");
    }
    else{

         while(change!=NULL && change->data!=n)
        {
            change=change->next;
        }
        if(change==NULL)
       {
            printf("Not found value\n");
       }
       else if(change->next==NULL)
       {
           printf("No node after this.\n");
       }
       else if(change->next->next==NULL)
       {
           head=del_at_end(head);
       }
       else{
           change=change->next;
           change->prev->next=change->next;
           change->next->prev=change->prev;
           temp=change;
           free(temp);
       }
    }
    return head;

}

struct node* delete_before_n_val(struct node* head)
{
    struct node *temp, *change=head;
    int n;
    printf("\nEnter n: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("List doesn't exist\n");
    }
    else if(head->data==n)
    {
        printf("No node before this\n");
    }
    else if(head->next->data==n)
    {
        head= delete_1st_node(head);
    }
    else{

         while(change->next!=NULL && change->next->data!=n)
        {
            change=change->next;
        }
        if(change->next==NULL)
       {
            printf("Not found n\n");
       }
       else{
           change->prev->next=change->next;
           change->next->prev=change->prev;
           temp=change;
           free(temp);
       }
    }
    return head;

}
