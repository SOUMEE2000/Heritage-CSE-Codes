void print(struct node *head)
{
    struct node* change=head;
    while(change!=NULL)
    {
        printf("%d ", change->data);
        change=change->next;
    }
    printf("\n");
}

void search(struct node *head)
{
    struct node* change=head;
    int n;
    printf("Enter n: ");
    scanf("%d",&n);
    while(change!=NULL & change->data==n)
    {
        change=change->next;
    }
    if(change==NULL)
        printf("Not found\n");
    else
        printf("Found\n");
}

void count(struct node *head)
{
    struct node* change=head;
    int count=0;
    while(change!=NULL)
    {
        count++;
        change=change->next;
    }
    printf("\n Count is %d\n", count);
}
