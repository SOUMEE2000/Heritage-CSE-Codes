struct node* ins_at_beg(struct node *head)
{
    struct node* temp;
    if (head==NULL)
    {
        temp=new_node();
        head=temp;
    }
    else{
        temp=new_node();
        temp->next=head;
        head->prev=temp;
        head=temp;
    }
    return head;
}

struct node *ins_at_end(struct node* head)
{
    struct node *temp, *change=head;
    if(head==NULL)
    {
        head=ins_at_beg(head);
    }
    else
    {
        while(change->next!=NULL)
            change=change->next;

        temp=new_node();
        change->next=temp;
        temp->prev=change;
    }
    return head;
}

struct node* ins_at_n_pos(struct node* head)
{
    int i,n;
    struct node* temp, *change=head;;
    printf("Enter the position: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        head=ins_at_beg(head);

        return head;
    }
    for(i=0; i<n-2; i++)
    {
        change=change->next;
    }
    if(change->next==NULL)
    {
        head=ins_at_end(head);
        return head;
    }
    temp=new_node();
    temp->next=change->next;
    change->next->prev=temp;
    temp->prev=change;
    change->next=temp;

    return head;
}

struct node* ins_after_n_val(struct node* head)
{
    int i,n;
    struct node* temp, *change=head;;
    printf("Enter the value: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("List doesn't exist\n");
        return head;
    }
    while(change!=NULL && change->data!=n)
    {
        change=change->next;
    }
    if(change==NULL)
    {
        printf("Value doesn't exist\n");
        return head;
    }
    if(change->next==NULL)
    {
        head=ins_at_end(head);
        return head;
    }

    if(change->data==n)
    {
        temp=new_node();
        temp->next=change->next;
        change->next->prev=temp;
        temp->prev=change;
        change->next=temp;
    }

    return head;
}

struct node* ins_before_n_val(struct node* head)
{
    int i,n;
    struct node* temp, *change=head;;
    printf("Enter the value: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("List doesn't exist\n");
        return head;
    }
    if(head->data==n)
    {
        head=ins_at_beg(head);
        return head;
    }
    while(change->next!=NULL && change->next->data!=n)
    {
        change=change->next;
    }
    if(change->next==NULL)
    {
        printf("Value doesn't exist\n");
        return head;
    }

        temp=new_node();
        temp->next=change->next;
        change->next->prev=temp;
        temp->prev=change;
        change->next=temp;

    return head;
}
