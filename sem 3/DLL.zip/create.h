struct node
{
    int data;
    struct node *next;
    struct node *prev;
};

struct node * new_node()
{
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    printf("Enter data: ");
    scanf("%d",&temp->data);
    temp->next=NULL;
    temp->prev=NULL;
    return temp;
}

struct node * list_by_user(struct node* head)
{
    struct node* change, *temp;
    int choice;
    do{
      if(head==NULL)
      {
          temp=new_node();
          temp->prev=head;
          head=temp;
          change=temp;
      }
      else{
          temp=new_node();
          change->next=temp;
          temp->prev=change;
          change=temp;
      }
      printf("Press 0 to quit and 1 to continue \n");
      scanf("%d", &choice);
    }while(choice);
    return head;
}

struct node* list_n_nodes(struct node* head)
{
    int n,i;
    struct node* temp, *change;
    printf("Enter number of nodes: ");
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        temp=new_node();
        if(head==NULL)
        {
            temp->prev=head;
            head=temp;
            change=temp;
        }
        else
        {
            change->next=temp;
            temp->prev=change;
            change=temp;
        }
    }
    return head;
}
