struct node* del_1st_node(struct node*head)
{
    struct node* temp, *change;
    if(head==NULL)
    {
        printf("Create a list first.\n");
        return head;
    }
    temp=head;
    change=head->prev;
    change->next=head->next;
    head->next->prev=change;
    head=head->next;
    free(temp);
    return head;
}

struct node* del_at_end(struct node* head)
{
    struct node* temp, *change;
    if(head==NULL)
    {
        printf("Create a list first.\n");
        return head;
    }
    temp=head->prev;
    change=head->prev->prev;
    change->next=head;
    head->prev=change;
    free(temp);
    return head;
}

struct node* delete_n_val(struct node* head)
{
    struct node* temp, *change=head;
    int n;
    printf("Enter the val: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("Create a list first.\n");
        return head;
    }
    if(head->data==n)
    {
        head=del_1st_node(head);
    }
    else
    {
        change=change->next;
        while(change!=head && change->data!=n)
        {
            change=change->next;
        }
        if(change==head)
        {
            printf("Value doesn't exist\n");
        }
        else
        {
            temp=change;
            change->prev->next=change->next;
            change->next->prev=change->prev;
            free(temp);
        }
    }
    return head;
}

struct node* delete_after_n_val(struct node* head)
{
    struct node* temp, *change=head;
    int n;
    printf("Enter the val: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("Create a list first.\n");
        return head;
    }
    if(head->data==n)
    {
        temp=head->next;
        head->next->next->prev=head;
        head->next=head->next->next;
        free(temp);
    }
    else
    {
        change=change->next;
        while(change!=head && change->data!=n)
        {
            change=change->next;
        }
        if(change==head)
        {
            printf("Value doesn't exist\n");
        }
        else if(change->next==head)
        {
            printf("No node exists after that.\n");
        }
        else
        {
            temp=change->next;
            change->next->next->prev=change;
            change->next=change->next->next;
            free(temp);
        }
    }
    return head;

}

struct node* delete_before_n_val(struct node* head)
{
    struct node* temp, *change=head;
    int n;
    printf("Enter the val: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("Create a list first.\n");
        return head;
    }
    if(head->data==n)
    {
        printf("No node before this.\n");
    }
    else if(head->next->data==n)
    {
        head=del_1st_node(head);
    }
    else
    {
        change=change->next;
        while(change!=head && change->data!=n)
        {
            change=change->next;
        }
        if(change==head)
        {
            printf("Value doesn't exist\n");
        }
        else
        {
            temp=change->prev;
            temp->prev->next=change;
            change->prev=temp->prev;
            free(temp);
        }
    }
    return head;
}
