struct node
{
    int data;
    struct node * next;
    struct node * prev;
};

struct node* new_node()
{
    int n;
    struct node *temp=(struct node*)malloc(sizeof(struct node));
    printf("Enter data: ");
    scanf("%d", &n);
    temp->data= n;
    temp->prev=NULL;
    temp->next=NULL;
    return temp;
}

struct node* list_by_user(struct node* head)
{
    struct node *temp, *change=head;
    int n;
    do
    {
        temp=new_node();
        if(head==NULL)
        {
            temp->next=temp;
            temp->prev=temp;
            head=temp;
            change=temp;
        }
        else
        {
            temp->next=head;
            head->prev=temp;
            change->next=temp;
            temp->prev=change;
            change=temp;
        }
        printf("Enter 1 to continue, 0 to exit\n");
        scanf("%d", &n);
    }while(n);
    return head;
}

struct node* list_n_nodes(struct node* head)
{
    int i, n;
    struct node*temp, *change=head;
    printf("Enter number of nodes: ");
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        temp=new_node();
        if(head==NULL)
        {
            temp->next=temp;
            temp->prev=temp;
            head=temp;
            change=temp;
        }
        else
        {
            temp->next=head;
            head->prev=temp;
            change->next=temp;
            temp->prev=change;
            change=temp;
        }
    }
    return head;
}
