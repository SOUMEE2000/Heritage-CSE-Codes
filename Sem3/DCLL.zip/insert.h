struct node* ins_at_beg(struct node* head)
{
    struct node* temp;
    temp=new_node();
    if(head==NULL)
    {
        temp->next=temp;
        temp->prev=temp;
        head=temp;
    }
    else{
        temp->next=head;
        head->prev->next=temp;
        temp->prev=head->prev;
        head->prev=temp;
        head=temp;
    }
    return head;
}

struct node* ins_at_end(struct node* head)
{
    struct node* temp;
    temp=new_node();
    if(head==NULL)
    {
        temp->next=temp;
        temp->prev=temp;
        head=temp;
    }
    else{
        temp->next=head;
        head->prev->next=temp;
        temp->prev=head->prev;
        head->prev=temp;
    }
    return head;
}

struct node * ins_at_n_pos(struct node * head)
{
    int i, n;
    struct node *temp, *change=head;
    printf("Enter position: ");
    scanf("%d",&n);
    if(n==1)
    {
        head=ins_at_beg(head);
        return head;
    }
    change=change->next;
    for(i=1; i<n-2; i++)
    {
        change=change->next;
    }
    if(change->next==head)
    {
        head=ins_at_end(head);
    }
    else{
        temp=new_node();
        temp->next=change->next;
        change->next->prev=temp;
        change->next=temp;
        temp->prev=change;
    }
    return head;

}

struct node * ins_before_n_val(struct node *head)
{
    int n,i;
    struct node* temp, *change=head;
    printf("Enter value: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("List doesn't exist\n");
        return head;
    }
    if(head->data==n)
    {
        head=ins_at_beg(head);
    }
    else
    {
        while(change->next!=head && change->next->data!=n)
        {
            change=change->next;
        }
        if(change->next==head)
        {
            printf("Value not found.\n");
        }
        else
        {
            temp=new_node();
            temp->next=change->next;
            change->next->prev=temp;
            change->next=temp;
            temp->prev=change;
        }
    }
    return head;
}

struct node * ins_after_n_val(struct node *head)
{
    int n,i;
    struct node* temp, *change=head;
    printf("Enter value: ");
    scanf("%d",&n);
    if(head==NULL)
    {
        printf("List doesn't exist\n");
        return head;
    }
    if(head->data==n)
    {
        temp=new_node();
        temp->next=change->next;
        change->next->prev=temp;
        change->next=temp;
        temp->prev=change;
    }
    else
    {
        change=change->next;
        while(change!=head && change->data!=n)
        {
            change=change->next;
        }
        if(change==head)
        {
            printf("Value not found.\n");
        }
        else
        {
            temp=new_node();
            temp->next=change->next;
            change->next->prev=temp;
            change->next=temp;
            temp->prev=change;
        }
    }
    return head;
}

